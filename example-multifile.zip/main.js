const gr = GoldRush;
const { makeIcon } = require('./lib/util');
const defs = require('./data/gems.json');
for (const g of defs) {
  gr.addItem({ id: g.id, name: g.name, icon: makeIcon(gr, g), price: g.price });
  gr.addBlock({ id: g.id + '_ore', name: g.name + ' (руда)', icon: { ore: g.color }, hp: g.hp, life: 3, xp: 8,
    minLevel: g.level, weights: { '*': g.weight }, drops: { [g.id]: [1, 2] }, coins: [5, 15] });
}
gr.addItem({ id: 'gems_badge', name: 'Значок', icon: { texture: gr.asset('img/badge.png') } });
gr.toast('Набор самоцветов загружен: ' + defs.length);
